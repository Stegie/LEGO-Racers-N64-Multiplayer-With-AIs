Version History.

.5 Initial Version (18Oct2026)

.7 Keep Captain Patch (19Oct2026)
This version retains the captain cars and exits the game safely after a match